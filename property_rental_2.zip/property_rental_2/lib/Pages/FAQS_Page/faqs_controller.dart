import 'package:get/get.dart';

class FaqsController extends GetxController {
  var tabBarIndex = 0.obs;
}