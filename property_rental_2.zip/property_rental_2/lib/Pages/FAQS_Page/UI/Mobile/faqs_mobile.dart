import 'package:flutter/material.dart';

class FaqsMobile extends StatelessWidget {
  const FaqsMobile({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
