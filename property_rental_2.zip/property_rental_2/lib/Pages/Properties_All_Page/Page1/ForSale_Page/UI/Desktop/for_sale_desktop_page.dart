import 'package:flutter/material.dart';

class ForSaleDesktopPage extends StatelessWidget {
  const ForSaleDesktopPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
