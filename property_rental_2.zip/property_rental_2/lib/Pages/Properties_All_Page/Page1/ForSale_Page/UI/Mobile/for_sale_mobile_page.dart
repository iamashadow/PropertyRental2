import 'package:flutter/material.dart';

class ForSaleMobilePage extends StatelessWidget {
  const ForSaleMobilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
