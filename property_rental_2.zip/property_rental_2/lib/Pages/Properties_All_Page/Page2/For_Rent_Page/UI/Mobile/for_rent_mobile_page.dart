import 'package:flutter/material.dart';

class ForRentMobilePage extends StatelessWidget {
  const ForRentMobilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
