import 'package:flutter/material.dart';

class OurPartnersMobilePage extends StatelessWidget {
  const OurPartnersMobilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
