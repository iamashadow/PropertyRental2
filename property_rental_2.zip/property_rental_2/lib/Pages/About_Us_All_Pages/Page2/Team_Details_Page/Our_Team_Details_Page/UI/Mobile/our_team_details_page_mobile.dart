import 'package:flutter/material.dart';

class OurTeamDetailsPageMobile extends StatelessWidget {
  const OurTeamDetailsPageMobile({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
