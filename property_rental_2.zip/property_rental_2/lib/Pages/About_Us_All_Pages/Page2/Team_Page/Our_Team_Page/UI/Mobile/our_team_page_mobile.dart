import 'package:flutter/material.dart';

class OurTeamPageMobile extends StatelessWidget {
  const OurTeamPageMobile({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
