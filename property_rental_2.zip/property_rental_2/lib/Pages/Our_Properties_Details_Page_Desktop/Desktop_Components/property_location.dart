import 'package:flutter/material.dart';

class PropertyLocation extends StatelessWidget {
  const PropertyLocation({super.key});

  @override
  Widget build(BuildContext context) {
    return const Text("Property map");
  }
}
