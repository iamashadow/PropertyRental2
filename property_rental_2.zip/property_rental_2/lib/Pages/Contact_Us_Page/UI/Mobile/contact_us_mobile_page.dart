import 'package:flutter/material.dart';

class ContactUsMobilePage extends StatelessWidget {
  const ContactUsMobilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Contact us Mobile Version"),
      ),
    );
  }
}
