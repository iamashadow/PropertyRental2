import 'package:flutter/material.dart';

class OurBuyingServiceMobilePage extends StatelessWidget {
  const OurBuyingServiceMobilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
