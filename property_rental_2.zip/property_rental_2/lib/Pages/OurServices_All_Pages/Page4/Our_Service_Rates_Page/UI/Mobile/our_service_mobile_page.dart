import 'package:flutter/material.dart';

class OurServiceMobilePage extends StatelessWidget {
  const OurServiceMobilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
