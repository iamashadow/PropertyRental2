import 'package:flutter/material.dart';

class OurRentalServiceMobile extends StatelessWidget {
  const OurRentalServiceMobile({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
