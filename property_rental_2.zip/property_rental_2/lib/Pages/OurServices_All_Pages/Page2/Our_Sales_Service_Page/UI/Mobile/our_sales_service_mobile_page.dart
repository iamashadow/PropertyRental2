import 'package:flutter/material.dart';

class OurSalesServiceMobilePage extends StatelessWidget {
  const OurSalesServiceMobilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
