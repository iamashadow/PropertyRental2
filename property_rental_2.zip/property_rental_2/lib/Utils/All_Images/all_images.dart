class AllImages{
  static const  String aboutUsImage1 = "assets/images/about_us_image.jpg";
  static const String aboutUsImage3 = "assets/images/about_us_image_3.jpg";
  static const String about_us_badge_ribbon = "assets/images/about_us_badge_ribbon.png";



  static const String ourStoryHeadImage = "assets/images/Partners/JB-Makelaars-Team.jpg";

  //OurPartnersLogoPic

  static const String AMSLanguageStudioLogoWebsite = "assets/images/Partners/AMS-Language-Studio-Logo-Website.png";
  static const String AMSLanguageStudioLogoWebsiteLink = "https://nlist.nl/nl";


  static const String boshuiswaterontharderslogo = "assets/images/Partners/boshuis-waterontharders-logo.png";
  static const String boshuiswaterontharderslogoWebsiteLink = "https://virtuagym.com/";


  static const String clairfortenret = "assets/images/Partners/clairfort-en-ret.png";
  static const String clairfortenretWebsiteLink = "https://uhpservices.nl/";


  static const String croppedcroppedLogoImageOnlySquare = "assets/images/Partners/cropped-cropped-Logo-Image-Only-Square.jpeg";
  static const String croppedcroppedLogoImageOnlySquareWebsiteLink = "https://aedvice.nl/";


  static const String EMlogoe1679488304842 = "assets/images/Partners/EM_logo-e1679488304842.png";
  static const String EMlogoe1679488304842WebsiteLink = "https://lumaconsulting.nl/";


  static const String ExpatRelocation = "assets/images/Partners/JExpat-Relocation.png";
  static const String ExpatRelocationWebsiteLink = "https://expatmortgages.nl/";

  static const String irolavglobetrotterslogoBluecopy = "assets/images/Partners/irolav-globetrotters_logo-Blue-copy.png";
  static const String irolavglobetrotterslogoBluecopyWebsiteLink = "https://tailorminds.com/en/";


  static const String Kuierkosblacke1676372079140 = "assets/images/Partners/Kuierkos-black-e1676372079140.png";
  static const String Kuierkosblacke1676372079140WebsiteLink = "https://www.boshuis.nl/";


  static const String LumaCONSULTINGLOGO = "assets/images/Partners/Luma-CONSULTING-LOGO-2048x885.png";
  static const String LumaCONSULTINGLOGOWebsiteLink = "https://www.ivoryplum.co.za/";


  static const String NLISTlogo = "assets/images/Partners/NLIST-logo.png";
  static const String NLISTlogoWebsiteLink = "https://www.kuierkos.com/";


  static const String Screenshot = "assets/images/Partners/Screenshot-2023-03-31-at-11.22.13.png";
  static const String ScreenshotWebsiteLink = "https://vanmarlemortgages.nl/";


  static const String TailorMindslogo = "assets/images/Partners/Tailor-Minds-logo.png";
  static const String TailorMindslogoWebsiteLink = "https://expatrelocations.nl/";


  static const String UHPlogo = "assets/images/Partners/UHP-logo.png";
  static const String UHPlogoWebsiteLink = "https://expatrelocations.nl/";


  static const String vanmarlelogo = "assets/images/Partners/van-marle-logo.jpeg";
  static const String vanmarlelogoWebsiteLink = "https://clairfort.nl/";


  static const String virtuagymlogoblackorange = "assets/images/Partners/virtuagym-logo-black-orange.png";
  static const String virtuagymlogoblackorangeWebsiteLink = "https://amslanguagestudio.com/nl/";




}