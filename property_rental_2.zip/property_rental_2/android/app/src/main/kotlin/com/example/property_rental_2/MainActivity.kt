package com.example.property_rental_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
